'use client'

import { useState } from 'react'
import { GoogleMap, Marker, InfoWindow } from '@react-google-maps/api'
import AddressSearchWithAutocomplete from '@/components/AddressSearchWithAutocomplete'

const mapContainerStyle = {
  width: '100%',
  height: '500px'
}

const defaultCenter = {
  lat: 40.7128,
  lng: -74.0060
}

const options = {
  disableDefaultUI: false,
  zoomControl: true,
  mapTypeControl: true,
  streetViewControl: true,
  fullscreenControl: true,
}

export default function WorkingMapDemo() {
  const [center, setCenter] = useState(defaultCenter)
  const [address, setAddress] = useState('')
  const [showInfoWindow, setShowInfoWindow] = useState(false)

  const handleSearch = (searchAddress: string, coordinates?: { lat: number; lng: number }) => {
    setAddress(searchAddress)
    if (coordinates) {
      setCenter(coordinates)
      setShowInfoWindow(true)
    }
  }

  return (
    <div className="container mx-auto p-8">
      <h1 className="text-3xl font-bold mb-4">Working Google Maps Demo</h1>
      
      <div className="mb-6">
        <p className="text-gray-600 mb-4">
          This is a working example of Google Maps integration. Search for any address to see it on the map.
        </p>
        
        <div className="max-w-xl">
          <AddressSearchWithAutocomplete
            onSearch={handleSearch}
            placeholder="Search for any address..."
          />
        </div>
      </div>

      <div className="rounded-lg overflow-hidden shadow-lg">
        <GoogleMap
          mapContainerStyle={mapContainerStyle}
          zoom={15}
          center={center}
          options={options}
        >
          <Marker
            position={center}
            onClick={() => setShowInfoWindow(true)}
          />
          
          {showInfoWindow && (
            <InfoWindow
              position={center}
              onCloseClick={() => setShowInfoWindow(false)}
            >
              <div className="p-2">
                <h3 className="font-semibold">{address || 'Selected Location'}</h3>
                <p className="text-sm text-gray-600">
                  Lat: {center.lat.toFixed(6)}, Lng: {center.lng.toFixed(6)}
                </p>
              </div>
            </InfoWindow>
          )}
        </GoogleMap>
      </div>

      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-blue-50 p-4 rounded-lg">
          <h3 className="font-semibold mb-2">Features Working:</h3>
          <ul className="text-sm space-y-1">
            <li>✅ Google Maps display</li>
            <li>✅ Address search with autocomplete</li>
            <li>✅ Map markers</li>
            <li>✅ Info windows</li>
            <li>✅ Zoom and pan controls</li>
          </ul>
        </div>
        
        <div className="bg-green-50 p-4 rounded-lg">
          <h3 className="font-semibold mb-2">Current Location:</h3>
          <p className="text-sm">{address || 'New York, NY (default)'}</p>
          <p className="text-sm text-gray-600 mt-1">
            Coordinates: {center.lat.toFixed(6)}, {center.lng.toFixed(6)}
          </p>
        </div>
      </div>
    </div>
  )
}