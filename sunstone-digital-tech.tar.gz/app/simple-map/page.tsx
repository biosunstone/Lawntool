'use client'

import { GoogleMap, useJsApiLoader } from '@react-google-maps/api'

const mapContainerStyle = {
  width: '100%',
  height: '400px'
}

const center = {
  lat: 40.7128,
  lng: -74.0060
}

export default function SimpleMapPage() {
  const { isLoaded, loadError } = useJsApiLoader({
    googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || '',
    libraries: ['places']
  })

  if (loadError) {
    return (
      <div className="p-8">
        <h1 className="text-xl font-bold text-red-600">Error loading maps</h1>
        <pre>{JSON.stringify(loadError, null, 2)}</pre>
      </div>
    )
  }

  if (!isLoaded) {
    return (
      <div className="p-8">
        <h1 className="text-xl font-bold">Loading Google Maps...</h1>
      </div>
    )
  }

  return (
    <div className="p-8">
      <h1 className="text-xl font-bold mb-4">Simple Google Map Test</h1>
      <div className="mb-4 p-4 bg-gray-100 rounded">
        <p>API Key: {process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY ? 'Present' : 'Missing'}</p>
        <p>Libraries Loaded: {isLoaded ? 'Yes' : 'No'}</p>
      </div>
      <GoogleMap
        mapContainerStyle={mapContainerStyle}
        center={center}
        zoom={15}
        options={{ mapTypeId: 'satellite' }}
      />
    </div>
  )
}